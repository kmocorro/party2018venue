let mysql = require('mysql');

/** tokens */
let authSecret = {
    secret : 'notasecretifyoualreadyknowthis'
}

/** DB Credentials for PARTY server */
let poolParty = mysql.createPool({
    multipleStatements: true,
    connectionLimit: 1000,
    //host: 'localhost',
    host: 'ddolfsb30gea9k.c36ugxkfyi6r.us-west-2.rds.amazonaws.com',
    user: 'kmocorro',
    password: 'kmocorro123',
    database: 'fab4_apps_db'
});

exports.poolParty = poolParty;
exports.authSecret = authSecret;