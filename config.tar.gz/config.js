let mysql = require('mysql');

/** tokens */
let authSecret = {
    secret : 'itsnotasecretifyoualreadyknowthis'
}

/** DB Credentials for PARTY server */
let poolParty = mysql.createPool({
    multipleStatements: true,
    connectionLimit: 1000,
    //host: 'localhost',
    host: 'localhost',
    user: 'root',
    password: 'Password123',
    database: 'fab4_apps_db'
});

exports.poolParty = poolParty;
exports.authSecret = authSecret;